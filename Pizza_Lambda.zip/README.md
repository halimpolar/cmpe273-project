# cmpe273-project

Tasks: https://docs.google.com/spreadsheets/d/1dtcKd8Umc7dL7FABi6nFR2944qALhjTpbjHLnRORR0Q/edit?ts=5834db13#gid=0

Menu List: https://docs.google.com/spreadsheets/d/1rJ6-8LPsQJFXMeQVC-RfruSuF5IQO57Oujvl2FHjgR8/edit?usp=sharing

## Test the Project
Jusk upload 'Pizza_Lambda.zip' to Lambda and make sure schema and utterances are as same as the ones which are alexa_schema and output

SLOTS:  
Type ----- Values  	
crust_type ----- Hand Tossed | Handmade | Crunchy Thin Crust | Brooklyn Style | Gluten Free  
name_type ----- name  
pizza_type ----- Extravaganzza | Meatzza | Philly Cheese Steak | Pacific Veggie | Honolulu Hawaiian | Deluxe | Cali Chicken Bacon Ranch | Buffalo Chicken | Ultimate Pepperoni | Memphis BBQ Chicken | Wisconsin Six Challenge | Spinach and Feta   
size_type ----- Small | Medium | Large | Extra Large  
bake_type ----- Well Done | Normal  
sauce_type ----- Robust Inspired Tomato | Hearty Marinara | Barbeque | Garlic Parmesan White | Alfredo   
cut_type ----- Pie | Square | Uncut  
seasoning_type ----- Garlic Seasoned Crust | None  
topping_type ----- None | Pepperoni | Sliced Italian Sausage | Philly Steak | Bacon | Premium Chicken | Italian Sausage | Beef | Ham | Salami | Cheddar Cheese | Shredded Parmesan Asiago | Banana Peppers | Garlic | Jalapeno Peppers | Pineapple | Roasted Red Peppers | Tomatoes | Hot Sauce | Feta Cheese | Shredded Provolone Cheese | Black Olives | Green Peppers | Mushrooms | Onions | Spinach | Diced Tomatoes   

