# cmpe273-project

Tasks: https://docs.google.com/spreadsheets/d/1dtcKd8Umc7dL7FABi6nFR2944qALhjTpbjHLnRORR0Q/edit?ts=5834db13#gid=0

Menu List: https://docs.google.com/spreadsheets/d/1rJ6-8LPsQJFXMeQVC-RfruSuF5IQO57Oujvl2FHjgR8/edit?usp=sharing

## Test the Project
Jusk upload 'Pizza_Lambda.zip' to Lambda and make sure schema and utterances are as same as the ones which are alexa_schema and output

SLOTS:  
Type	             Values  	
crust_type	        crust  
name_type	          name  
pizza_type	        pizza  
size_type	          size  
