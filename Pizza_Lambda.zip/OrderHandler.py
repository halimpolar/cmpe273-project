from __future__ import print_function
import json
from oauth2client.service_account import ServiceAccountCredentials
from httplib2 import Http
from apiclient.discovery import build


class OrderHandler:
    def __init__(self):
        scopes = ['https://www.googleapis.com/auth/spreadsheets']
        credentials = ServiceAccountCredentials.from_json_keyfile_name(
                'Alexa_Pizza.json', scopes)
        http_auth = credentials.authorize(Http())
        self.service = build('sheets', 'v4', http=http_auth)
        self.sheetID = '1rJ6-8LPsQJFXMeQVC-RfruSuF5IQO57Oujvl2FHjgR8'
        self.sheetName = 'TestAPI'

    '''
    def placeOrder(self, order):
        rangeName = self.sheetName + '!A2:A'
        result = self.service.spreadsheets().values().get(
            spreadsheetId=self.sheetID, range=rangeName).execute()
        values = result.get('values', [])
        # write
        values = [
            [
                'Frank2', 'UCB', 40
            ]
        ]
        body = {
            'values': values
        }
        result = service.spreadsheets().values().append(
                spreadsheetId=spreadsheetId, range=rangeName,
                valueInputOption='RAW', body=body).execute()
    '''

    def write(self):
        spreadsheetId = '1rJ6-8LPsQJFXMeQVC-RfruSuF5IQO57Oujvl2FHjgR8'
        # spreadsheetId = '1aewyN8RXI6oPPUWC7q0yy1s_umfdj-13QBZzGmPCNBA'
        rangeName = 'TestAPI!A2:C'
        # write
        values = [
            [
                'XXXXFrank2XXX', 'XXXXUCBXXX', 'XXX100'
            ]
        ]
        body = {
            'values': values
        }
        result = self.service.spreadsheets().values().append(
                spreadsheetId=spreadsheetId, range=rangeName,
                valueInputOption='RAW', body=body).execute()

if __name__ == '__main__':
    test = OrderHandler()
    test.write()
